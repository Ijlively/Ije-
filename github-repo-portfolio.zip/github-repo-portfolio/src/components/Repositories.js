import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { Button } from '@chakra-ui/react';
import RepoModal from './RepoModal';

function Repositories() {
  const [repos, setRepos] = useState([]);
  const [page, setPage] = useState(1);
  const [isModalOpen, setIsModalOpen] = useState(false);

  useEffect(() => {
    axios.get(`https://api.github.com/users/your_username/repos?page=${page}&per_page=10`)
      .then(response => setRepos(response.data))
      .catch(error => console.error(error));
  }, [page]);

  const nextPage = () => {
    setPage(page + 1);
  };

  const prevPage = () => {
    setPage(page - 1);
  };

  const openModal = () => {
    setIsModalOpen(true);
  };

  const closeModal = () => {
    setIsModalOpen(false);
  };

  return (
    <div>
      <h1>Your Repositories</h1>
      <Button onClick={openModal}>Create Repo</Button>
      <ul>
        {repos.map(repo => (
          <li key={repo.id}>{repo.name}</li>
        ))}
      </ul>
      <Button onClick={prevPage} disabled={page === 1}>Previous</Button>
      <Button onClick={nextPage}>Next</Button>
      <RepoModal isOpen={isModalOpen} onClose={closeModal} />
    </div>
  );
}

export default Repositories;
