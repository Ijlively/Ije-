import React, { useState } from 'react';
import { Modal, ModalOverlay, ModalContent, ModalHeader, ModalFooter, ModalBody, ModalCloseButton, Button, FormControl, FormLabel, Input } from '@chakra-ui/react';
import axios from 'axios';

function RepoModal({ isOpen, onClose, repo }) {
  const [name, setName] = useState(repo ? repo.name : '');
  const [description, setDescription] = useState(repo ? repo.description : '');

  const handleSave = () => {
    if (repo) {
      // Update existing repository
      axios.patch(`https://api.github.com/repos/your_username/${repo.name}`, { name, description })
        .then(response => {
          console.log('Repository updated:', response.data);
          onClose();
        })
        .catch(error => console.error('Error updating repository:', error));
    } else {
      // Create new repository
      axios.post('https://api.github.com/user/repos', { name, description })
        .then(response => {
          console.log('Repository created:', response.data);
          onClose();
        })
        .catch(error => console.error('Error creating repository:', error));
    }
  };

  const handleDelete = () => {
    if (repo) {
      axios.delete(`https://api.github.com/repos/your_username/${repo.name}`)
        .then(() => {
          console.log('Repository deleted:', repo.name);
          onClose();
        })
        .catch(error => console.error('Error deleting repository:', error));
    }
  };

  return (
    <Modal isOpen={isOpen} onClose={onClose}>
      <ModalOverlay />
      <ModalContent>
        <ModalHeader>{repo ? 'Update Repo' : 'Create Repo'}</ModalHeader>
        <ModalCloseButton />
        <ModalBody>
          <FormControl>
            <FormLabel>Name</FormLabel>
            <Input type="text" value={name} onChange={e => setName(e.target.value)} />
          </FormControl>
          <FormControl>
            <FormLabel>Description</FormLabel>
            <Input type="text" value={description} onChange={e => setDescription(e.target.value)} />
          </FormControl>
        </ModalBody>
        <ModalFooter>
          {repo && (
            <Button colorScheme="red" mr={3} onClick={handleDelete}>
              Delete
            </Button>
          )}
          <Button colorScheme="blue" mr={3} onClick={onClose}>
            Close
          </Button>
          <Button variant="ghost" onClick={handleSave}>{repo ? 'Update' : 'Create'}</Button>
        </ModalFooter>
      </ModalContent>
    </Modal>
  );
}

export default RepoModal;
