import React, { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import axios from 'axios';

function RepositoryDetails() {
  const { repoId } = useParams();
  const [repo, setRepo] = useState(null);

  useEffect(() => {
    axios.get(`https://api.github.com/repos/your_username/${repoId}`)
      .then(response => setRepo(response.data))
      .catch(error => console.error(error));
  }, [repoId]);

  return (
    <div>
      <h2>Repository Details</h2>
      {repo && (
        <div>
          <h3>{repo.name}</h3>
          <p>{repo.description}</p>
          {/* Add more details as needed */}
        </div>
      )}
    </div>
  );
}

export default RepositoryDetails;
