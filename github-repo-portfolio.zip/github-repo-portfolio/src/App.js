import { BrowserRouter as Router, Switch, Route } from 'react-router-dom';
import Repositories from './components/Repositories';
import RepositoryDetails from './components/RepositoryDetails';

function App() {
  return (
    <Router>
      <Switch>
        <Route path="/" exact component={Repositories} />
        <Route path="/repo/:repoId" component={RepositoryDetails} />
      </Switch>
    </Router>
  );
}

export default App;
