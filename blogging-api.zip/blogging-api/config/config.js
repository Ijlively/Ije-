module.exports = {
    secretKey: 'your_secret_key',
    tokenExpiration: '1h',
    pagination: {
        defaultLimit: 20
    },
    logging: {
        level: 'info'
    }
};
