const express = require('express');
const router = express.Router();
const blogController = require('../controllers/blogController');
const authUtils = require('../utils/authUtils');

router.get('/blogs', blogController.getAllBlogs);
router.get('/blogs/:id', blogController.getBlogById);
router.post('/blogs', authUtils.authenticateUser, blogController.createBlog);
router.put('/blogs/:id', authUtils.authenticateUser, blogController.updateBlog);
router.delete('/blogs/:id', authUtils.authenticateUser, blogController.deleteBlog);

module.exports = router;
