const User = require('../models/User');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const config = require('../config/config');

exports.signup = async (req, res) => {
    try {
        // Code for user signup
    } catch (error) {
        // Error handling
    }
};

exports.signin = async (req, res) => {
    try {
        // Code for user signin
    } catch (error) {
        // Error handling
    }
};
